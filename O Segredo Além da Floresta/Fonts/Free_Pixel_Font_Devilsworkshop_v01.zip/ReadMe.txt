 +-+-+-+-+-+-+-+ +-+-+-+-+-+-+-+-+-+
 |D|e|v|i|l|'|s| |W|o|r|k|.|s|h|o|p|
 +-+-+-+-+-+-+-+ +-+-+-+-+-+-+-+-+-+

::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::

License 



By downloading and installing this font for free you agree to the following license

- This is a free font and you can use it for commercial and non commercial work
- this font should not be sold
- YOu can embed this font in a mobile / pc / web application 
- you can embed this fonts graphics 
- This font may not be redistributed, shared, repackaged
- the font creator Ajay Karat / Devil's Work.shop makes no warranties about the work, and disclaims liability for all use of the works, to the fullest extent permitted by the applicable law. 



::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::

credits is not needed, but is much appreciated 

Ajay Karat | Devil's Work.shop
http://devilswork.shop/
http://twitter.com/devilswork_shop 

::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::


If you like this font Pack, please consider taking a moment to rate/review it. Your continued support helps The Devil's Workshop bring new improvements to the pack!


help@devilswork.shop


::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::





